exports.handler = async () => {
    return {
        body: 'Hello from lambda'
    }
}